#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<string.h>
#include<pthread.h>
#include<semaphore.h>
sem_t mutex1,mutex2;
void *thread_t1()
{
  while(1){
     sem_wait(&mutex1);
     printf("X");
     usleep(1);
     printf("x");
    sem_post(&mutex2);
  }
}

void *thread_t2() 
{
   while(1){
     sem_wait(&mutex2);
     printf("O");
     usleep(1);
     printf("o");
sem_post(&mutex1);
    }	
}

void main()
{
   int res;
   sem_init(&mutex1,0,1);
   sem_init(&mutex2,1,0);
   pthread_t a_thread;
   res=pthread_create(&a_thread,NULL,thread_t1,NULL);
   if(res!=0){perror("Thread creation failure!\n");}
   res=pthread_create(&a_thread,NULL,thread_t2,NULL);
   if(res!=0){perror("Thread creation failure!\n");}

   sleep(10);
    printf("\n");
}






