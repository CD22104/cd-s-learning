#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<unistd.h>
#include<string.h>
#include<pthread.h>
#include<semaphore.h>
/*模拟生产者消费者问�?代码编写:2017-2018-1,操作系统--朱继�?
  说明:
  代码中的sleep语句或者usleep均为尽量使生产者和消费者尽量交叉执行而设�?与问题本身的解决方案无关.
  代码中有些统计数据和显示语句也非必须,只为验证程序的正确性而设�?
  适用于多个生产者和消费者问�?
  代码仅为教学使用,旨在让学生更好的掌握信号量解决进程同步的一般方�?
  程序运行过程的随机性是因为线程的调�?请同学们分析程序结果,理解线程(进程)调度过程.
  */
#define PNUM 2   //生产者线程数
#define CNUM 2 //消费者线程数
#define N 20   //生产者和消费者循环次�?
#define BUF_SIZE 10
int count=0;
int in=0;
int out=0;
char buffer[BUF_SIZE]="----------";

sem_t full,empty,mutex; //定义三个信号�?
/*full表示缓冲区可消费的数据项;
  empty表示缓冲区可生产的数据项;
  mutex用于生产者和消费者之间的互斥
*/


void display()   //display buffer 
{
	
	int i;
	printf("count=%2d,in=%2d,out=%2d,buffer=",count,in,out);
	for(i=0;i<BUF_SIZE;i++)
      //printf("%c",buffer[i]); //正常从缓冲区位置0显示
	 printf("%c",buffer[(i+out)%BUF_SIZE]);//从缓冲区位置out的地方循环显�?便于观察结果
        printf("\n");
}

void *producer(void *arg)
{       int i=0;
	while((i++)<N)
	{      
 		 sem_wait(&empty);
		sem_wait(&mutex);		
		printf("P%ld执行%2d�?",(unsigned long)arg,i);  		
		buffer[in]='X';
        usleep(8000);
		count++;
        in=(in+1)%BUF_SIZE;
		display();
		sem_post(&mutex);
		sem_post(&full);
	}
}

void *consumer(void *arg)
{
	int i=0;
	while((i++)<N)
       {   
		sem_wait(&full);
		sem_wait(&mutex);
		printf("C%ld执行%2d�?",(unsigned long)arg,i);  		
		count--;
        usleep(5000);
		buffer[out]='-';
        out=(out+1)%BUF_SIZE;
		display();
	sem_post(&mutex);
	sem_post(&empty);
	}
}
void main()
{
   int res;
   int i;
   pthread_t producer_thread[PNUM],consumer_thread[CNUM];
  sem_init(&empty,0,BUF_SIZE);
  sem_init(&full,0,0);
  sem_init(&mutex,0,1);
   for(i=0;i<PNUM;i++){//创建生产者线�?    
      res=pthread_create(&producer_thread[i],NULL,producer,(void*)(unsigned long)(i));
      if(res!=0){perror("Thread creation failure!\n");}
   }
   for(i=0;i<CNUM;i++){//创建消费者线�?
    res=pthread_create(&consumer_thread[i],NULL,consumer,(void*)(unsigned long)(i)); 
    if(res!=0){perror("Thread creation failure!\n");}
   }
   for(i=0;i<PNUM;i++){ //进程等待所有子生产者线程结�?
       pthread_join(producer_thread[i],NULL);
    }
   for(i=0;i<CNUM;i++){ //进程等待所有子消费者线程结�?
         pthread_join(consumer_thread[i],NULL);
   }
    printf("两个生产者和两� ��消费者都执行完成:\n");
    display();
    printf("\n");
}






