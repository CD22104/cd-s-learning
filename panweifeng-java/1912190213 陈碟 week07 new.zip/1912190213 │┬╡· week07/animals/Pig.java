package animals;

public class Pig extends Animal{
//	public String catogory;
//	public float weight;
//	public float bodyLen;
//	public void say()
//	{
//		System.out.println("cat says...");
//	}
//	public void walk()
//	{
//		System.out.println("cat walks");
//	}
	public void eat()
	{
		System.out.println("i can eat a lot");
	}

}
