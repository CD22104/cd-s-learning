package animals;

public class Dog extends Animal{
//	public String catogory;
//	public float weight;
//	public float bodyLen;
//	public void say()
//	{
//		System.out.println("dog says...");
//	}
//	public void walk()
//	{
//		System.out.println("dog walks");
//	}
	public void company()
	{
		System.out.println("i can cssompany");
	}
	
}
