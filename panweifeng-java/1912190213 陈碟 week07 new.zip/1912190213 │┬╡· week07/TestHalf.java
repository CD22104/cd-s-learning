package experiment;

public class TestHalf {
	public static void main(String[] args) {
		Halfresearch a = new Halfresearch();
		int[] m= {1,2,3,4,5,6,7,8,14,43};
		int k;
		k=a.binarySearch(m, 8);
		System.out.println(k);
	}
}  
