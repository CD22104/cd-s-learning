package week09;

public class PetShop {
	public String shopname;
	public Pet[] pets=new Pet[1000];;
}
