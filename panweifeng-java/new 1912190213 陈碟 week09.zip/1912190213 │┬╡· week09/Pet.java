package week09;

public class Pet {
	public String name;
	public int age;
	public int weight;
	public int activity;
}
